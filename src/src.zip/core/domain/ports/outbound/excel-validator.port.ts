export interface ExcelValidatorPort {
    validateColumns(columns: string[]): boolean;
  }
  