import * as XLSX from 'xlsx';
import { Inject, Injectable } from '@nestjs/common';
import { ExcelValidatorPort } from '@/core/domain/ports/outbound/excel-validator.port';

@Injectable()
export class ExcelFileService {
  constructor(
    @Inject('ExcelValidatorPort') // Aquí inyectamos el token 'ExcelValidatorPort'
    private readonly validator: ExcelValidatorPort,
  ) {}

  readAndValidateExcel(filePath: string): any {
    console.log('got here');
    try {
      const workbook = XLSX.readFile(filePath);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      // Validate columns using the injected validator
      if (!this.validator.validateColumns(data[0] as string[])) {
        throw new Error(
          'The provided Excel file does not have the expected columns.',
        );
      }
      return data;
    } catch (error) {
      throw new Error(
        'An error occurred while processing the Excel file. Error message:' + error.message,
      );
    }
  }
}
