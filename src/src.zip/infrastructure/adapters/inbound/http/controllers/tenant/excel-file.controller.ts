import { Controller, Post, UploadedFile, UseInterceptors, HttpException, HttpStatus } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiConsumes, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ExcelFileService } from 'src/core/application/services/tenant/excel-file.service';

@ApiTags('excel')
@Controller('excel')
export class ExcelFileController {
  constructor(private readonly excelFileService: ExcelFileService) {}

  @Post('upload')
  @ApiOperation({ summary: 'Upload an Excel file for processing' })
  @ApiResponse({ status: 201, description: 'File processed successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    console.log(file);
    console.log("hello stars!");
    if (!file) {
      throw new HttpException('File must be provided.', HttpStatus.BAD_REQUEST);
    }

    try {
      // Procesar y validar el archivo Excel
      const data = await this.excelFileService.readAndValidateExcel(file.path);
      return { message: 'File processed successfully', data };
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }
}
