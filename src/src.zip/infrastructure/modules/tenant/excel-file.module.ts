import { ExcelFileController } from '@/infrastructure/adapters/inbound/http/controllers/tenant/excel-file.controller';
import { Module } from '@nestjs/common';
import { ExcelFileService } from 'src/core/application/services/tenant/excel-file.service';
import { InvoiceExcelValidator } from 'src/core/application/services/validators/invoice-excel-validator';


console.log('ExcelFileService:', ExcelFileService);
@Module({
  controllers: [ExcelFileController],
  providers: [
    ExcelFileService,
    {
      provide: 'ExcelValidatorPort',
      useClass: InvoiceExcelValidator,
    },
  ],
})
export class ExcelFileModule {}
