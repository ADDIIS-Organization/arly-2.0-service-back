export interface IRoleSeed {
  name: string;
  description: string;
}
