export interface ICediSeed {
  name: string;
  department: string;
  municipality: string;
  address: string;
  phone: string;
  primaryEmail: string;
  secondaryEmail: string;
  supervisor: string;
  company: string;
}