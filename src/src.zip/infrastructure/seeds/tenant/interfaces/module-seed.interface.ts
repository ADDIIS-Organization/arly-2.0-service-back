export interface IModuleSeed {
  name: string;
  icon: string;
}
