export interface IMenuItemSeed {
    name: string;
    route: string;
    moduleName: string;
    parentName?: string;
  }
  